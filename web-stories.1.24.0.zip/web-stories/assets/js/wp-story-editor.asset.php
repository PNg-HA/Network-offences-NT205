<?php return array('dependencies' => array('wp-api-fetch', 'wp-dom-ready'), 'version' => 'd3fd8338f8aa3dc20995');
