<?php return array('dependencies' => array(), 'version' => '89ef7afd5e5aad4fec37');
