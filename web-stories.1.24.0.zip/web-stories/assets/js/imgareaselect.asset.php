<?php return array('dependencies' => array(), 'version' => '9de3dfb96988488d32ae');
