<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '589a9e7885e45a55fa5c');
