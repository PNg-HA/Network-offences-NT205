<?php return array('dependencies' => array(), 'version' => '345e53e045c3dde135e1');
