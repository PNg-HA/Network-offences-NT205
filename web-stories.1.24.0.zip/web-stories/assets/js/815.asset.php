<?php return array('dependencies' => array(), 'version' => '27ad87b084a2d0b1b363');
