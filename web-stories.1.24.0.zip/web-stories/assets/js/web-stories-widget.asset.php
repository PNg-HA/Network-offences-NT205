<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '80341c2e2aa666c1641b');
