<?php return array('dependencies' => array('react', 'wp-element', 'wp-i18n'), 'version' => 'e9e2c6d531fadf9d7a05');
