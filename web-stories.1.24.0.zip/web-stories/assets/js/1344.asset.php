<?php return array('dependencies' => array(), 'version' => '6b63f44446f2af02fcfb');
