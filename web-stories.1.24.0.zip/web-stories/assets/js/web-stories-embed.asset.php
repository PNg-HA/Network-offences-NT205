<?php return array('dependencies' => array(), 'version' => '2f635975a5e3c86f266d');
