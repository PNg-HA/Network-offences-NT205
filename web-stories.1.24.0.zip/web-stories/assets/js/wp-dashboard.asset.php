<?php return array('dependencies' => array('wp-api-fetch', 'wp-dom-ready'), 'version' => 'd9ad12de7d18cc440b0f');
