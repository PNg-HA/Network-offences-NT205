<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'ed8b2e0575abd8572f7b');
