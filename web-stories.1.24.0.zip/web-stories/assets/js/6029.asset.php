<?php return array('dependencies' => array(), 'version' => '7ca23ca8b3d70e48a942');
